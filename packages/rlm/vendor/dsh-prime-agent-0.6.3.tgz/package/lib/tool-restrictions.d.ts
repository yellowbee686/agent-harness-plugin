import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "prime-agent-tool-restrictions";
export declare const inject: string[];
export interface Config {
    /** Inherited Host-global tools hidden whenever their providers are present. */
    deny: string[];
}
export declare const Config: z<Config>;
/** Keep each joined Agent's inherited capability mask synchronized with Host tools. */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=tool-restrictions.d.ts.map