/** Prime-authored context provenance, separate from model, tool, and user input. */
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        prime: {
            readonly kind: 'prime';
            readonly name: string;
        };
    }
}
export {};
//# sourceMappingURL=message-source.d.ts.map